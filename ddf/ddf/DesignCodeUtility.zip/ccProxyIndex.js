#!/usr/bin/env node

return require("./src/mainProxy").main(process.argv)
