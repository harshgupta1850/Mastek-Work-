#!/usr/bin/env node

return require("./src/ccwMain").main(process.argv)
