#!/usr/bin/env node

return require("./src/dcuMain").main(process.argv)
